from flask import Flask,redirect,render_template,url_for,flash
from forms import RegistrationForm, LogInForm 
app=Flask(__name__)
app.config['SECRET_KEY']='927d3370b05f51bd344c50f24c54758a'


posts=[
  {'title':'First Blog',
   'content':'First Blog',
   'date_posted':'12/09/2024',
   'author':'Leo Kim'
   },
  
  
  {'title':'Second Blog',
   'content':'Second Blog content',
   'date_posted':'12/09/2024',
   'author':'Mum Cheru'},



  {'title':'Third Blog',
   'content':'Second Blog content',
   'date_posted':'12/09/2024',
   'author':'Mum Cheru'}
   
   
   ]

@app.route("/")
@app.route("/home")
def home():
    return render_template("home.html",posts=posts)


@app.route("/about")
def about():
    return render_template("about.html",title='About')

@app.route("/register",methods=['GET','POST'])
def register():
    form= RegistrationForm()
    if form.validate_on_submit():
        flash(f'Account created for {form.username.data}!','success')
        return redirect(url_for('home'))
    return render_template('register.html',form=form)

@app.route("/login")
def login():
    form= LogInForm()
    return render_template('login.html',form=form)


if __name__  == '__main__' :
    app.run(debug=True) 